from collections import Iterator

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import Dataset, DataLoader, Sampler

import cs3600.dataloader_utils as dataloader_utils

from . import dataloaders


class KNNClassifier(object):
    def __init__(self, k):
        self.k = k
        self.x_train = None
        self.y_train = None
        self.n_classes = None

    def train(self, dl_train: DataLoader):
        """
        Trains the KNN model. KNN training is memorizing the training data.
        Or, equivalently, the model parameters are the training data itself.
        :param dl_train: A DataLoader with labeled training sample (should
            return tuples).
        :return: self
        """

        # TODO:
        #  Convert the input dataloader into x_train, y_train and n_classes.
        #  1. You should join all the samples returned from the dataloader into
        #     the (N,D) matrix x_train and all the labels into the (N,) vector
        #     y_train.
        #  2. Save the number of classes as n_classes.
        # ====== YOUR CODE: ======
        x_train = []
        y_train = []
        for tup in list(dl_train): # lazy
            x_train.append(tup[0])
            y_train.append(tup[1])
        n_classes = len(set(y_train))
        x_train = torch.cat(x_train)
        y_train = torch.cat(y_train)

        # ========================
        self.x_train = x_train
        self.y_train = y_train
        self.n_classes = n_classes
        return self

    def predict(self, x_test: Tensor):
        """
        Predict the most likely class for each sample in a given tensor.
        :param x_test: Tensor of shape (N,D) where N is the number of samples.
        :return: A tensor of shape (N,) containing the predicted classes.
        """

        # Calculate distances between training and test samples
        dist_matrix = l2_dist(self.x_train, x_test)

        # TODO:
        #  Implement k-NN class prediction based on distance matrix.
        #  For each training sample we'll look for it's k-nearest neighbors.
        #  Then we'll predict the label of that sample to be the majority
        #  label of it's nearest neighbors.

        n_test = x_test.shape[0]
        y_pred = torch.zeros(n_test, dtype=torch.int64)
        for i in range(n_test):
            # TODO:
            #  - Find indices of k-nearest neighbors of test sample i
            #  - Set y_pred[i] to the most common class among them
            #  - Don't use an explicit loop.
            # ====== YOUR CODE: ======
            min_ks = np.argpartition(dist_matrix[:,i],self.k)[:self.k] # take min k indices
            y_pred[i] = np.argmax(np.bincount(self.y_train[min_ks])) # take max of classes bins
            # ========================

        return y_pred


def l2_dist(x1: Tensor, x2: Tensor):
    """
    Calculates the L2 (euclidean) distance between each sample in x1 to each
    sample in x2.
    :param x1: First samples matrix, a tensor of shape (N1, D).
    :param x2: Second samples matrix, a tensor of shape (N2, D).
    :return: A distance matrix of shape (N1, N2) where the entry i, j
    represents the distance between x1 sample i and x2 sample j.
    """

    # TODO:
    #  Implement L2-distance calculation efficiently as possible.
    #  Notes:
    #  - Use only basic pytorch tensor operations, no external code.
    #  - Solution must be a fully vectorized implementation, i.e. use NO
    #    explicit loops (yes, list comprehensions are also explicit loops).
    #    Hint: Open the expression (a-b)^2. Use broadcasting semantics to
    #    combine the three terms efficiently.
    #  - Don't use torch.cdist

    dists = None
    # ====== YOUR CODE: ======
    dists = (-2 * (x2 @ x1.T) + torch.sum(x1 ** 2, axis=1) + torch.sum(x2 ** 2, axis=1)[:,np.newaxis]).T
    assert(dists.shape == (x1.shape[0], x2.shape[0]))
    dists = torch.sqrt(dists)

    # ========================

    return dists


def accuracy(y: Tensor, y_pred: Tensor):
    """
    Calculate prediction accuracy: the fraction of predictions in that are
    equal to the ground truth.
    :param y: Ground truth tensor of shape (N,)
    :param y_pred: Predictions vector of shape (N,)
    :return: The prediction accuracy as a fraction.
    """
    assert y.shape == y_pred.shape
    assert y.dim() == 1

    # TODO: Calculate prediction accuracy. Don't use an explicit loop.
    accuracy = None
    # ====== YOUR CODE: ======
    accuracy = len(y[(y == y_pred)]) / y.shape[0]
    # ========================

    return accuracy


def find_best_k(ds_train: Dataset, k_choices, num_folds):
    """
    Use cross validation to find the best K for the kNN model.

    :param ds_train: Training dataset.
    :param k_choices: A sequence of possible value of k for the kNN model.
    :param num_folds: Number of folds for cross-validation.
    :return: tuple (best_k, accuracies) where:
        best_k: the value of k with the highest mean accuracy across folds
        accuracies: The accuracies per fold for each k (list of lists).
    """

    accuracies = []

    for i, k in enumerate(k_choices):
        model = KNNClassifier(k)

        # TODO:
        #  Train model num_folds times with different train/val data.
        #  Don't use any third-party libraries.
        #  You can use your train/validation splitter from part 1 (note that
        #  then it won't be exactly k-fold CV since it will be a
        #  random split each iteration), or implement something else.

        # ====== YOUR CODE: ======
        class CV_Sampler(Sampler):
            def __init__(self, datasource, indices: list):
                super().__init__(datasource)
                self.data_source = datasource
                self.indices = indices
            def __iter__(self):
                for i in range(len(self.indices)):
                    yield self.indices[i]

        cur_accs = []
        splits = np.split(np.array((range(len(ds_train)))), num_folds) # Create num_fold splits
        for fold, val_inds in enumerate(splits): # for each fold create a Sampler for train and val, and predict on val
            val_sampler = CV_Sampler(ds_train, val_inds)
            train_inds = np.setdiff1d(splits, val_inds)
            train_sampler = CV_Sampler(ds_train, train_inds)
            model.train(DataLoader(ds_train, sampler=train_sampler))
            dl_valid = DataLoader(ds_train, sampler=val_sampler)
            x_val, y_val = dataloader_utils.flatten(dl_valid)
            preds = model.predict(x_val)
            cur_acc = accuracy(y_val, preds)
            cur_accs.append(cur_acc)
            print(f'Testing K of {k}, Cur Fold {fold} Acc {cur_acc}')
        accuracies.append(cur_accs)
        # ========================

    best_k_idx = np.argmax([np.mean(acc) for acc in accuracies])
    best_k = k_choices[best_k_idx]

    return best_k, accuracies
